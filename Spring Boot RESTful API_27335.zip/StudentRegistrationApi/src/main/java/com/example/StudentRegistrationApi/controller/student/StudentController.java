package com.example.StudentRegistrationApi.controller.student;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.StudentRegistrationApi.model.student.Student;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final List<Student> students = new ArrayList<>();

    public StudentController() {
        
        students.add(new Student(1L, "Alice", "Johnson", "alice@test.com", "Computer Science", 3.8));
        students.add(new Student(2L, "Bob", "Smith", "bob@test.com", "Mathematics", 3.2));
        students.add(new Student(3L, "Charlie", "Davis", "charlie@test.com", "Computer Science", 3.9));
        students.add(new Student(4L, "Diana", "Prince", "diana@test.com", "Physics", 3.4));
        students.add(new Student(5L, "Eve", "White", "eve@test.com", "Computer Science", 2.9));
    }

    
    @GetMapping
    public List<Student> getAllStudents() {
        return students;
    }

    
    @GetMapping("/{studentId}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long studentId) {
        return students.stream()
                .filter(s -> s.getStudentId().equals(studentId))
                .findFirst()
                .map(student -> new ResponseEntity<>(student, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND)); 
    }

    
    @GetMapping("/major/{major}")
    public List<Student> getStudentsByMajor(@PathVariable String major) {
        return students.stream()
                .filter(s -> s.getMajor().equalsIgnoreCase(major))
                .collect(Collectors.toList());
    }

    
    @GetMapping("/filter")
    public List<Student> filterByGpa(@RequestParam Double gpa) {
        return students.stream()
                .filter(s -> s.getGpa() >= gpa)
                .collect(Collectors.toList());
    }

    
    @PostMapping
    public ResponseEntity<Student> registerStudent(@RequestBody Student student) {
        students.add(student);
        return new ResponseEntity<>(student, HttpStatus.CREATED); 
    }

    @PutMapping("/{studentId}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long studentId, @RequestBody Student updatedStudent) {
        for (Student s : students) {
            if (s.getStudentId().equals(studentId)) {
                s.setFirstName(updatedStudent.getFirstName());
                s.setLastName(updatedStudent.getLastName());
                s.setEmail(updatedStudent.getEmail());
                s.setMajor(updatedStudent.getMajor());
                s.setGpa(updatedStudent.getGpa());
                return new ResponseEntity<>(s, HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}