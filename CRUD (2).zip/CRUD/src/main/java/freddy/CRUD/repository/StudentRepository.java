package freddy.CRUD.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import freddy.CRUD.model.Student;


@Repository
public interface StudentRepository extends JpaRepository<Student,Long>{

    
}